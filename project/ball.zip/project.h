#ifndef CHILLY_SNOW_H
#define CHILLY_SNOW_H

#include <windows.h>
#include <GL/glut.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>

#define pi 3.14159265
#define speed_add 0.000001
#define TREE_NUM 15

typedef struct
{
	float x;
	float y;
	float size;
} forest;

forest tree[TREE_NUM]; //пассивная агрессия таким людям //вообще это можно спрятать в мэйн //может лучше в чили_сноу
double speed = 0.025;   //сделайте с этим что-нибудь, мне аж самому плохо

void plant_tree (int i, double y_pos);
void print_tree (forest tree);
void reshape (int w, int h);
void create_forest (void);
void chilly_snow (void);
void background (void);
void timer (int t);

#endif